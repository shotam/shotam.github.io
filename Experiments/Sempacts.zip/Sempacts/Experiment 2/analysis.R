##### specify working directory #####
wd = "/Volumes/LabFiles/Shota/Analysis/Sempacts/"
exp = "Experiment 2/"

##### Pre-analysis #####
# Load packages + Kleiman re-corder
library(lme4)
source(paste0(wd, "Kleinman_recoder.R"))

# read data
Exp2 = read.table(paste0(wd, exp, 'data.dat'), header=T) 
Exp2 = recode.vars(Exp2, c("PrimeType","ExpCond"), contr.sum, scaleLevelDiffsTo1=T)

##### Create full model to compare against #####
Exp2.full<- glmer(TargBinary ~ PrimeType.lev + ExpCond.lev + PrimeType.lev:ExpCond.lev
                       + (1 + PrimeType.lev + ExpCond.lev + PrimeType.lev:ExpCond.lev || Subject) + (1 + PrimeType.lev + ExpCond.lev + PrimeType.lev:ExpCond.lev || Trial)
                       , data = Exp2, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))
                
with(Exp2.full@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Create model without PrimeType #####
Exp2.NoPrimeType<- glmer(TargBinary ~ ExpCond.lev + PrimeType.lev:ExpCond.lev
                       + (1 + PrimeType.lev + ExpCond.lev + PrimeType.lev:ExpCond.lev || Subject) + (1 + PrimeType.lev + ExpCond.lev + PrimeType.lev:ExpCond.lev || Trial)
                       , data = Exp2, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))
                       
with(Exp2.NoPrimeType@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)
       
##### Create model without ExpCond #####
Exp2.NoExpCond<- glmer(TargBinary ~ PrimeType.lev + PrimeType.lev:ExpCond.lev
                       + (1 + PrimeType.lev + ExpCond.lev + PrimeType.lev:ExpCond.lev || Subject) + (1 + PrimeType.lev + ExpCond.lev + PrimeType.lev:ExpCond.lev || Trial)
                       , data = Exp2, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))
                       
with(Exp2.NoExpCond@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Create model without PrimeType x ExpCond interaction #####

Exp2.NoInteraction<- glmer(TargBinary ~ PrimeType.lev + ExpCond.lev 
                       + (1 + PrimeType.lev + ExpCond.lev + PrimeType.lev:ExpCond.lev || Subject) + (1 + PrimeType.lev + ExpCond.lev + PrimeType.lev:ExpCond.lev || Trial)
                       , data = Exp2, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))
                  
with(Exp2.full@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Conduct Maximum Likelihood Ratio tests #####
MLR_PrimeType <- anova(Exp2.full, Exp2.NoPrimeType); capture.output(MLR_PrimeType, file = paste0(wd,exp, 'MLR_PrimeType.txt'))
MLR_ExpCond <- anova(Exp2.full, Exp2.NoExpCond); capture.output(MLR_ExpCond, file = paste0(wd,exp, 'MLR_ExpCond.txt'))
MLR_interaction <- anova(Exp2.full, Exp2.NoInteraction); capture.output(MLR_interaction, file = paste0(wd,exp, 'MLR_interaction.txt'))
