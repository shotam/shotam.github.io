##### specify working directory #####
wd = "/Volumes/LabFiles/Shota/Analysis/Sempacts/"
exp = "Experiment 4/"

##### Pre-analysis #####
# Load packages + Kleiman re-corder
library(lme4)
source(paste0(wd, "Kleinman_recoder.R"))

# read data
Exp4 = read.table(paste0(wd, exp, 'data.dat'), header=T) 
Exp4 = recode.vars(Exp4, c("PrimeType", "CardTyp"), contr.sum, scaleLevelDiffsTo1=T)

##### Create full model to compare against #####
Exp4.full<- glmer(TargBinary ~ PrimeType.lev + CardTyp.lev + PrimeType.lev:CardTyp.lev
                  + (1 + PrimeType.lev + CardTyp.lev + PrimeType.lev:CardTyp.lev || Subject) + (1 + PrimeType.lev + CardTyp.lev + PrimeType.lev:CardTyp.lev || Item)
                  , data = Exp4, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))

with(Exp4.full@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Create model without PrimeType #####
Exp4.NoPrimeType<- glmer(TargBinary ~ CardTyp.lev + PrimeType.lev:CardTyp.lev
                         + (1 + PrimeType.lev + CardTyp.lev + PrimeType.lev:CardTyp.lev || Subject) + (1 + PrimeType.lev + CardTyp.lev + PrimeType.lev:CardTyp.lev || Item)
                         , data = Exp4, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))

with(Exp4.NoPrimeType@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Create model without CardTyp #####
Exp4.NoCardTyp<- glmer(TargBinary ~ PrimeType.lev + PrimeType.lev:CardTyp.lev
                       + (1 + PrimeType.lev + CardTyp.lev + PrimeType.lev:CardTyp.lev || Subject) + (1 + PrimeType.lev + CardTyp.lev + PrimeType.lev:CardTyp.lev || Item)
                       , data = Exp4, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))

with(Exp4.NoCardTyp@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Create model without PrimeType x CardTyp interaction #####

Exp4.NoInteraction<- glmer(TargBinary ~ PrimeType.lev + CardTyp.lev 
                           + (1 + PrimeType.lev + CardTyp.lev + PrimeType.lev:CardTyp.lev || Subject) + (1 + PrimeType.lev + CardTyp.lev + PrimeType.lev:CardTyp.lev || Item)
                           , data = Exp4, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))

with(Exp4.full@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Conduct Maximum Likelihood Ratio tests #####
MLR_PrimeType <- anova(Exp4.full, Exp4.NoPrimeType); capture.output(MLR_PrimeType, file = paste0(wd,exp, 'MLR_PrimeType.txt'))
MLR_CardTyp <- anova(Exp4.full, Exp4.NoCardTyp); capture.output(MLR_CardTyp, file = paste0(wd,exp, 'MLR_CardTyp.txt'))
MLR_interaction <- anova(Exp4.full, Exp4.NoInteraction); capture.output(MLR_interaction, file = paste0(wd,exp, 'MLR_interaction.txt'))
