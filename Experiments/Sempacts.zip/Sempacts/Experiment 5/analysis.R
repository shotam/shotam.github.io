##### specify working directory #####
wd = "/Volumes/LabFiles/Shota/Analysis/Sempacts/"
exp = "Experiment 5/"

##### Pre-analysis #####
# Load packages + Kleiman re-corder
library(lme4)
source(paste0(wd, "Kleinman_recoder.R"))

# read data
Exp5 = read.table(paste0(wd, exp, 'data.dat'), header=T)
Exp5 = recode.vars(Exp5, c("PrimeType", "Homogeneity"), contr.sum, scaleLevelDiffsTo1=T)

##### Create full model to compare against #####
Exp5.full<- glmer(TargBinary ~ PrimeType.lev + Homogeneity.lev + PrimeType.lev:Homogeneity.lev
                  + (1 + PrimeType.lev + Homogeneity.lev + PrimeType.lev:Homogeneity.lev || Subject) + (1 + PrimeType.lev + Homogeneity.lev + PrimeType.lev:Homogeneity.lev || Item)
                  , data = Exp5, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))

with(Exp5.full@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Create model without PrimeType #####
Exp5.NoPrimeType<- glmer(TargBinary ~ Homogeneity.lev + PrimeType.lev:Homogeneity.lev
                         + (1 + PrimeType.lev + Homogeneity.lev + PrimeType.lev:Homogeneity.lev || Subject) + (1 + PrimeType.lev + Homogeneity.lev + PrimeType.lev:Homogeneity.lev || Item)
                         , data = Exp5, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))

with(Exp5.NoPrimeType@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Create model without Homogeneity #####
Exp5.NoHomogeneity<- glmer(TargBinary ~ PrimeType.lev + PrimeType.lev:Homogeneity.lev
                       + (1 + PrimeType.lev + Homogeneity.lev + PrimeType.lev:Homogeneity.lev || Subject) + (1 + PrimeType.lev + Homogeneity.lev + PrimeType.lev:Homogeneity.lev || Item)
                       , data = Exp5, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))

with(Exp5.NoHomogeneity@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Create model without PrimeType x Homogeneity interaction #####

Exp5.NoInteraction<- glmer(TargBinary ~ PrimeType.lev + Homogeneity.lev 
                           + (1 + PrimeType.lev + Homogeneity.lev + PrimeType.lev:Homogeneity.lev || Subject) + (1 + PrimeType.lev + Homogeneity.lev + PrimeType.lev:Homogeneity.lev || Item)
                           , data = Exp5, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))

with(Exp5.full@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Conduct Maximum Likelihood Ratio tests #####
MLR_PrimeType <- anova(Exp5.full, Exp5.NoPrimeType); capture.output(MLR_PrimeType, file = paste0(wd,exp, 'MLR_PrimeType.txt'))
MLR_Homogeneity <- anova(Exp5.full, Exp5.NoHomogeneity); capture.output(MLR_Homogeneity, file = paste0(wd,exp, 'MLR_Homogeneity.txt'))
MLR_interaction <- anova(Exp5.full, Exp5.NoInteraction); capture.output(MLR_interaction, file = paste0(wd,exp, 'MLR_interaction.txt'))
