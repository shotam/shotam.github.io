##### specify working directory #####
wd = "/Volumes/LabFiles/Shota/Analysis/Sempacts/"
exp = "Experiment 1/"
##### Pre-analysis #####
# Load packages + Kleiman re-corder
library(lme4)
source(paste0(wd, "Kleinman_recoder.R"))

# read data
Exp1 = read.table(paste0(wd,exp, 'data.dat'), header=T) 
Exp1 = recode.vars(Exp1, c("PrimeType", "PrimeCategory"), contr.sum, scaleLevelDiffsTo1=T)

##### Create full model to compare against: #####
Exp1.full<- glmer(TargBInary ~ PrimeType.lev + PrimeCategory.lev1 + PrimeCategory.lev2 + PrimeType.lev:PrimeCategory.lev1 + PrimeType.lev:PrimeCategory.lev2
                       + (1 + PrimeType.lev + PrimeCategory.lev1 + PrimeCategory.lev2 + PrimeType.lev:PrimeCategory.lev1 + PrimeType.lev:PrimeCategory.lev2 || Subject) + (1 + PrimeType.lev || Trial)
                       , data = Exp1, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))
                       
summary(Exp1.full)
with(Exp1.full@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)

##### Create model without PrimeType #####

Exp1.NoPrimeType<- glmer(TargBInary ~ PrimeCategory.lev1 + PrimeCategory.lev2 + PrimeType.lev:PrimeCategory.lev1 + PrimeType.lev:PrimeCategory.lev2
                       + (1 + PrimeType.lev + PrimeCategory.lev1 + PrimeCategory.lev2 + PrimeType.lev:PrimeCategory.lev1 + PrimeType.lev:PrimeCategory.lev2 || Subject) + (1 + PrimeType.lev || Trial)
                       , data = Exp1, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))
                       
summary(Exp1.NoPrimeType)
with(Exp1.NoPrimeType@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)  

##### Create model without PrimeCategory  #####
Exp1.NoPrimeCategory<- glmer(TargBInary ~ PrimeType.lev + PrimeType.lev:PrimeCategory.lev1 + PrimeType.lev:PrimeCategory.lev2
                       + (1 + PrimeType.lev + PrimeCategory.lev1 + PrimeCategory.lev2 + PrimeType.lev:PrimeCategory.lev1 + PrimeType.lev:PrimeCategory.lev2 || Subject) + (1 + PrimeType.lev || Trial)
                       , data = Exp1, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))                       
                       
with(Exp1.NoPrimeCategory@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)                         
##### Create model without PrimeCategory x PrimeCategory interaction  #####
Exp1.NoInteraction<- glmer(TargBInary ~ PrimeType.lev + PrimeCategory.lev1 + PrimeCategory.lev2 
                       + (1 + PrimeType.lev + PrimeCategory.lev1 + PrimeCategory.lev2 + PrimeType.lev:PrimeCategory.lev1 + PrimeType.lev:PrimeCategory.lev2 || Subject) + (1 + PrimeType.lev || Trial)
                       , data = Exp1, family = binomial, verbose=T, control=glmerControl(optimizer="bobyqa"))

with(Exp1.NoPrimeCategory@optinfo$derivs,max(abs(solve(Hessian,gradient)))<2e-3)                         
##### Conduct Maximum Likelihood Ratio tests #####
MLR_PrimeType <- anova(Exp1.full, Exp1.NoPrimeType); capture.output(MLR_PrimeType, file = paste0(wd,exp, 'MLR_PrimeType.txt'))
MLR_PrimeCategory <- anova(Exp1.full, Exp1.NoPrimeCategory); capture.output(MLR_PrimeCategory, file = paste0(wd,exp, 'MLR_PrimeCategory.txt'))
MLR_interaction <- anova(Exp1.full, Exp1.NoInteraction); capture.output(MLR_interaction, file = paste0(wd,exp, 'MLR_interaction.txt'))
